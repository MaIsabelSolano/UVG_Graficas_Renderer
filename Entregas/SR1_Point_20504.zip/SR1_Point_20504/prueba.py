from gl_point import *

r = Render(1440,1440)

# Para probar se puede utilizar cualquier VP
#r.glViewPort(800, 800, 50, 100)
#r.glViewPort(1440, 1440)
r.glViewPort(100, 100)

r.glColor(RED)

r.Vertex(0.5, 0.6)
r.Vertex(0.0, 0.0)


r.glColor(GREEN)

r.Vertex(0.0, 0.5)

r.glFinish('SR1_point.bmp') 

